package com.other;

/*
 * @(#)OtherClass.java
 */
import com.test.ISecondInterface;

/**
 * This interface extends TWO other interfaces.
 *
 * @author  Marcel Schoen
 * @version $Id: ISomeInterface.java,v 1.1 2013/10/27 23:51:33 marcelschoen Exp $
 */
public interface ISomeInterface extends IOneInterface, ITwoInterface {

}

