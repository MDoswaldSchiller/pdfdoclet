These fonts have been downloaded from websites such as

http://www.fontfreak.com/index2.htm

However, they are not free of copyrights and are usually 
to be used for non-commercial purposes only.

ALSO NOTE THAT CERTAIN TTF FONTS CANNOT BE EMBEDDED BECAUSE
THEY ARE COPYRIGHTED (THE PDFDOCLET WILL FAIL TO CREATE THE PDF).